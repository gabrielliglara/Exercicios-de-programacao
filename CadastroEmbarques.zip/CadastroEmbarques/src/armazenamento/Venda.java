
package armazenamento;


public class Venda {
    private String paxPrincipal;
    private String orcamento;
    private String data;
    private String hotel;
    private String destino;

    public Venda(String paxPrincipal, String orcamento, String data, String hotel, String destino) {
        this.paxPrincipal = paxPrincipal;
        this.orcamento = orcamento;
        this.data = data;
        this.hotel = hotel;
        this.destino = destino;
    }
    
    public Venda(){
        
    }

    public void setPaxPrincipal(String paxPrincipal) {
        this.paxPrincipal = paxPrincipal;
    }

    public void setOrcamento(String orcamento) {
        this.orcamento = orcamento;
    }

    public void setData(String data) {
        this.data = data;
    }

    public void setHotel(String hotel) {
        this.hotel = hotel;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getPaxPrincipal() {
        return paxPrincipal;
    }

    public String getOrcamento() {
        return orcamento;
    }

    public String getData() {
        return data;
    }

    public String getHotel() {
        return hotel;
    }

    public String getDestino() {
        return destino;
    }

}
