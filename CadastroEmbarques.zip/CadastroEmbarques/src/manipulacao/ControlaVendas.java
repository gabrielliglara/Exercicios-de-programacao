
package manipulacao;

import armazenamento.Venda;
import java.util.ArrayList;

public class ControlaVendas {
    private ArrayList<Venda> vendas = new ArrayList<>();
    
    public boolean salvar(Venda v){
        if (v != null){
            vendas.add(v);
            return true;
        } else {
            return false;
        }
    }
    
    public ArrayList<Venda> retornarTodos(){
        return vendas;
    }
    
}
