
package cadastroembarques;

import apresentacao.MenuPrincipal;

public class CadastroEmbarques {

    public static void main(String[] args) {
        MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);        
    }
    
}
